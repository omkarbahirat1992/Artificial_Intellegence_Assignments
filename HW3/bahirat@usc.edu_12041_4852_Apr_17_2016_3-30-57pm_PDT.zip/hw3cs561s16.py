import sys
from decimal import Decimal
from collections import OrderedDict

def every(predicate, seq):
    for x in seq:
        if not predicate(x): return False
    return True

def reset_output_file():
    fp = open("output.txt", "w")
    fp.close()

def extend(dictionary, key, val):
    s2 = dictionary.copy()
    s2[key] = val
    return s2


class ProbDist:
    def __init__(self, varname='?', freqs=None):
        self.prob = {}
        self.varname = varname
        self.values = []
        if freqs:
            for (v, p) in list(freqs.items()):
                self[v] = p
            self.normalize()

    def __getitem__(self, val):
        try:
            return self.prob[val]
        except KeyError:
            return 0

    def __setitem__(self, val, p):
        if val not in self.values:
            self.values.append(val)
        self.prob[val] = p

    def normalize(self, bn):
        if (bn.variable_node(self.varname).D_node):
            return self

        total = sum(self.prob.values())
        if (total != 1.0):
            for val in self.prob:
                self.prob[val] /= total
        return self

    def show_approx(self, key):
        return self.prob[key]


def event_values(event, variables):
    if isinstance(event, tuple) and len(event) == len(variables):
        return event
    else:
        return tuple([event[var] for var in variables])

class BayesNet:
    def __init__(self, node_specs=[]):
        self.nodes = []
        self.variables = []
        for node_spec in node_specs:
            self.add(node_spec)

    def add(self, node_spec):
        node = BayesNode(*node_spec)
        assert node.variable not in self.variables
        assert every(lambda parent: parent in self.variables, node.parents)
        self.nodes.append(node)
        self.variables.append(node.variable)
        for parent in node.parents:
            self.variable_node(parent).children.append(node)

    def variable_node(self, var):
        for n in self.nodes:
            if n.variable == var:
                return n
        raise Exception("No such variable: %s" % var)

    def variable_values(self, var):
        return [True, False]

    def __repr__(self):
        return 'BayesNet(%r)' % self.nodes

class BayesNode:
    def __init__(self, X, parents, cpt, D_flag):
        if isinstance(parents, str):
            parents = parents.split()

        if isinstance(cpt, (float, int)):  # no parents, 0-tuple
            cpt = {(): cpt}
        elif isinstance(cpt, dict):
            if cpt and isinstance(list(cpt.keys())[0], bool):
                cpt = dict(((v,), p) for v, p in list(cpt.items()))

        assert isinstance(cpt, dict)
        for vs, p in list(cpt.items()):
            assert isinstance(vs, tuple) and len(vs) == len(parents)
            assert every(lambda v: isinstance(v, bool), vs)
            if (X != "utility"):
                assert 0 <= p <= 1.0

        self.variable = X
        self.parents = parents
        self.cpt = cpt
        self.D_node = D_flag
        self.children = []

    def p(self, value, event):
        assert isinstance(value, bool)
        if self.D_node:
            return 1
        ptrue = self.cpt[event_values(event, self.parents)]
        return (ptrue if value else 1 - ptrue)

    def __repr__(self):
        return repr((self.variable, ' '.join(self.parents)))


def enumeration_ask(X, e, bn):
    Q = ProbDist(X)
    for xi in bn.variable_values(X):
        Q[xi] = enumerate_all(bn.variables, extend(e, X, xi), bn)
    return Q.normalize(bn)

def enumerate_all(variables, e, bn):
    if not variables:
        return 1.0

    Y, rest = variables[0], variables[1:]
    Ynode = bn.variable_node(Y)

    if Y in e:
        return Ynode.p(e[Y], e) * enumerate_all(rest, e, bn)
    else:
        return sum(Ynode.p(y, e) * enumerate_all(rest, extend(e, Y, y), bn)
                   for y in bn.variable_values(Y))

def parse_node_name(line):
    node_name = ''
    parents = ''

    split = line.split("|")

    if line.find("|") != -1:
        node_name = split[0][:-1]
        parents = split[1][1:-1]
    else:
        node_name = split[0][:-1]

    node_tuple = (node_name,)
    node_tuple = node_tuple + (parents,)
    return node_tuple

def str2bool(str):
    if (str == "+"):
        return True
    return False

def prepare_Bn_and_query(file_name):
    query_list = []
    node_list = []
    line = ' '
    parent_flag = True

    fp = open(file_name, "r")

    for line in fp:
        if (line[:-1] == "******"):     
            break
        query_list.append(line[:-1])

    node_name = ' '
    parents = ' '
    key_tuple = ()
    value = ' '
    attrib_dict = {}
    first_line = True

    for line in fp:
        if (line[:-1] == "decision"):
            cur_node_tuple = cur_node_tuple + (1.0,)
            cur_node_tuple = cur_node_tuple + (True,)
            parent_flag = False
            continue
    
        if (line[:-1] == "***" or line[:-1] == "******"): 
            if (parent_flag == True):
                cur_node_tuple = cur_node_tuple + (attrib_dict,)
                cur_node_tuple = cur_node_tuple + (False,)
            else:
                parent_flag = True
            first_line = True
            node_list.append(cur_node_tuple)
            continue    

        if first_line:
            first_line = False
            attrib_dict = {}                # Need to have NEW instance of dictionary for each table
            cur_node_tuple = parse_node_name(line)

        else:
            split = line.split(' ')
            value = split[0]

            if (len(split[1:]) == 0):
                parent_flag = False
                cur_node_tuple = cur_node_tuple + (float(value[:-1]),)
                cur_node_tuple = cur_node_tuple + (False,)
                continue

            if (len(split[1:]) == 1):
                attrib_dict[str2bool(split[1][:1])] = float(value)

            elif (len(split[1:]) == 2):
                key_tuple = (str2bool(split[1]),)
                if (split[2].find('\n') != -1):
                    key_tuple = key_tuple + (str2bool(split[2][:-1]),)
                else:
                    key_tuple = key_tuple + (str2bool(split[2]),)
                attrib_dict[key_tuple] = float(value)

            elif (len(split[1:]) == 3):
                key_tuple = (str2bool(split[1]),)
                key_tuple = key_tuple + (str2bool(split[2]),)
                if (split[2].find('\n') != -1):
                    key_tuple = key_tuple + (str2bool(split[3][:-1]),)
                else:
                    key_tuple = key_tuple + (str2bool(split[3]),)
                attrib_dict[key_tuple] = float(value)
            

    if (parent_flag == True):
        cur_node_tuple = cur_node_tuple + (attrib_dict,)
        cur_node_tuple = cur_node_tuple + (False,)

    node_list.append(cur_node_tuple)
    return BayesNet(node_list), query_list

def parse_query(query):
    variables = ""
    evidence = ""

    split = query.split("|")

    if query.find("|") != -1:
        variables = split[0][:-1]
        evidence = split[1][1:]
    else:
        variables = split[0][:]
    return variables, evidence


def parse_var(variable):
    name = ""
    T_val = "decision"
    
    split = variable.split()

    if (len(split) == 1):
        name = split[0]
    else:
        name = split[0]
        T_val = str2bool(split[2])

    return name, T_val

def make_dictionary(evidence):
    e_dict = OrderedDict()
    if not evidence:
        return e_dict

    splits = evidence.split(",")
    
    for var in splits:
        key, val = parse_var(var)    
        e_dict[key] = val
    return e_dict
    
def process_joint_P_query(Bn, variables, evidence):
    variable_list = variables.split(",", 1)
    if (len(variable_list) == 1):
        return process_P_query(Bn, variable_list[0], evidence)
    return process_P_query(Bn, variable_list[0], evidence + variable_list[1]) * process_joint_P_query(Bn, variable_list[1], evidence)

def process_P_query(Bn, variables, evidence):
    if variables.find(",") != -1:
        if (evidence):
            return process_joint_P_query(Bn, variables + ", " + evidence, "") / process_P_query(Bn, evidence, "")
        return process_joint_P_query(Bn, variables, evidence)

    else:
        e_dict = {}
        var_name, T_val = parse_var(variables)
        if (evidence):
            e_dict = make_dictionary(evidence)
        return enumeration_ask(var_name, e_dict, Bn).show_approx(T_val)
    
def bool2str(var):
    return ("+" if var == True else "-")

def calculate_2_Parent_EU(Bn, utility_node, key, extended_evidence, e_dict):
    utility_parents = utility_node.parents
    EU = 0
    if utility_parents[0] not in e_dict and utility_parents[1] not in e_dict:       # None of the parent is in evidence
        parents  = utility_parents[0] + " = " + bool2str(key[0])
        parents += ", " + utility_parents[1] + " = " + bool2str(key[1])
        EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]

    elif utility_parents[0] in e_dict:          # 0th parent is in evidence
        if (e_dict[utility_parents[0]] == key[0]):
            parents  = utility_parents[1] + " = " + bool2str(key[1])
            EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]
    
    elif utility_parents[1] in e_dict:          # 1st parent is in evidence
        if (e_dict[utility_parents[1]] == key[1]):
            parents  = utility_parents[0] + " = " + bool2str(key[0])
            EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]
    return EU

def calculate_3_Parent_EU(Bn, utility_parents, key, extended_evidence, e_dict):
    utility_parents = utility_node.parents
    EU = 0
    if utility_parents[0] not in e_dict and utility_parents[1] not in e_dict and utility_parents[2] not in e_dict:  # None of the parent is in evidence
        parents  = utility_parents[0] + " = " + bool2str(key[0])
        parents += ", " + utility_parents[1] + " = " + bool2str(key[1])
        parents += ", " + utility_parents[2] + " = " + bool2str(key[2])
        EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]

    elif utility_parents[0] in e_dict and utility_parents[1] in e_dict:    # Only 0th and 1st parents are in evidence
            if (e_dict[utility_parents[0]] == key[0] and e_dict[utility_parents[1]] == key[1]):
                parents  = utility_parents[2] + " = " + bool2str(key[2])
                EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]
    
    elif utility_parents[0] in e_dict and utility_parents[2] in e_dict:    # Only 0th and 2nd parents are in evidence
            if (e_dict[utility_parents[0]] == key[0] and e_dict[utility_parents[2]] == key[2]):
                parents  = utility_parents[1] + " = " + bool2str(key[1])
                EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]

    elif utility_parents[1] in e_dict and utility_parents[2] in e_dict:    # Only 1st and 2nd parents are in evidence
            if (e_dict[utility_parents[1]] == key[1] and e_dict[utility_parents[2]] == key[2]):
                parents  = utility_parents[0] + " = " + bool2str(key[0])
                EU =  process_P_query(Bn, parents, extended_evidence) * utility_node.cpt[key]

    return EU


def process_EU_query(Bn, variables, evidence):
    e_dict = {}
    EU = 0

    utility_node = Bn.variable_node("utility")
    utility_parents = utility_node.parents

    extended_evidence = variables
    if (evidence):
        extended_evidence += ", " + evidence

    e_dict = make_dictionary(extended_evidence)

    for key in utility_node.cpt:
        if (len(key) == 1):         #Have only one parent
            EU +=  process_P_query(Bn, utility_parents[0] + " = " + bool2str(key[0]), extended_evidence) * utility_node.cpt[key]

        elif (len(key) == 2):       #Have two parents
            EU += calculate_2_Parent_EU(Bn, utility_node, key, extended_evidence, e_dict)
        elif (len(key) == 3):       #Have three parents
            EU += calculate_3_Parent_EU(Bn, utility_node, key, extended_evidence, e_dict)
    return EU

def dict2string(e_dict):
    string = ""
    for key in e_dict:
        string += str(key) + " = " + bool2str(e_dict[key]) + ","
    return string[:-1]

def make_grounded_var_dict(var_dict, e_dict):
    grounded_var_dict = {}
    for var in var_dict:
        if var in e_dict:
            grounded_var_dict[var] = e_dict[var]
    return grounded_var_dict



"""
var_sequence_dict{key: value}  :=
                    key = one of the variable whose MEU is asked.
                    value = serial number of that variable in the key_tuple of result_dict
        
e.g.:
        if query is: MEU(A, B, C)
        then var_sequence_dict = {'A': 0, 'B': 1, 'C': 2}
        result_dict = {
                            (True, True, True: <computed EU>)
                            (True, True, False: <computed EU>)
                            (True, False, True: <computed EU>)
                                .
                                .
                            (False, False, False: <computed EU>)
                        }
"""
def find_MAX_EU(result_dict, grounded_var_dict, var_sequence_dict):
    MEU = 0.0
    truth_values_tuple = ()

    for key in result_dict:         # "key" is tuple of truth values
        if result_dict[key] > MEU:
            match_flag = True
            for k1 in grounded_var_dict:
                if key[var_sequence_dict[k1]] != grounded_var_dict[k1]:
                    match_flag = False
                    break
            if match_flag == True:
                truth_values_tuple = key
                MEU = result_dict[key]
            
    return truth_values_tuple, MEU

def handle_n_var_MEU(Bn, var_sequence_dict, var_dict, e_dict):
    result_dict = {}
    if (len(var_sequence_dict) == 1):
        result_dict = {(True,): 0.0, (False,): 0.0}
    elif (len(var_sequence_dict) == 2):
        result_dict = {(True, True): 0.0 , (True, False): 0.0, (False, True): 0.0, (False, False): 0.0}
    elif (len(var_sequence_dict) == 1):
        result_dict = {(True, True, True): 0.0 , (True, True, False): 0.0, (True, False, True): 0.0, (True, False, False): 0.0,
                        (False, True, True): 0.0 , (False, True, False): 0.0, (False, False, True): 0.0, (False, False, False): 0.0}

    decision_seq_var_list = []
    for key in var_sequence_dict:
        decision_seq_var_list.insert(var_sequence_dict[key], key)   #"key" with value "i" will be at "i"th position in list

    # Remove all the evidences of decision nodes
    for var in decision_seq_var_list:    
        if var in e_dict:
            del e_dict[var]

    updated_var_dict = var_dict.copy()
    for key in result_dict:
        i = 0
        for var in decision_seq_var_list:    
            updated_var_dict[var] = key[i]   #"i"th variable will get "i"th key
            i += 1
        result_dict[key] = process_EU_query(Bn, dict2string(updated_var_dict), dict2string(e_dict))

    return result_dict


def process_MEU_query(Bn, variables, evidence):
    e_dict = make_dictionary(evidence)
    result_dict = {}
    var_dict = {}            # Dictionary of all the variables
    var_sequence_dict = {}   # Dictionary of only decision variables with sr. no. as per their given sequence
    sr_no = 0
    
    var_dict = make_dictionary(variables)
    for key in var_dict:
        if var_dict[key] == "decision":
            var_sequence_dict[key] = sr_no
        sr_no += 1

    result_dict = handle_n_var_MEU(Bn, var_sequence_dict, var_dict, e_dict)
    
    truth_value_tuple, MEU =  find_MAX_EU(result_dict, make_grounded_var_dict(var_dict, e_dict), var_sequence_dict)
    truth_value_string = ""
    for value in truth_value_tuple:
        truth_value_string += bool2str(value) + " "

    return truth_value_string  + str("%d" % round(Decimal(str(MEU)).quantize(Decimal('.01'))))


def write_output_file(output_list):
    fp = open("output.txt", "a")
    for str in output_list[:-1]:
        fp.write(str + "\n")
    fp.write(output_list[-1])
    fp.close

def process_query(Bn, query_list):
    output_list = []
    for query in query_list:
        if (query.startswith("P(")):
            output_list.append('%.2f' % process_P_query(Bn, *parse_query(query[2:-1])))

        elif (query.startswith("EU(")):
            output_list.append('%d' % round(process_EU_query(Bn, *parse_query(query[3:-1]))))

        elif (query.startswith("MEU(")):
            output_list.append(process_MEU_query(Bn, *parse_query(query[4:-1])))
            
    write_output_file(output_list)


def main(argv):
    input_file = ' '
    query_list = []
    Bn = None
    
    try:
        if (argv[0] == '-i'):
            input_file = argv[1]
        else:
            sys.exit(2)
    except:
        sys.exit(2)

    Bn, query_list = prepare_Bn_and_query(input_file)

    reset_output_file()
    process_query(Bn, query_list)

if __name__ == "__main__":
    main(sys.argv[1:])






'''
Key notes:

1) Input: A Bayesian network with may contain
            a) several decision nodes  b) A utility node

2) Output:
       1) IF (no decision node | decision node with set value) then calculate
            a) Specific Joint probabilities | Marginal probabilities | Conditional Probabilities

       2) ELSE  Calculate
            1) Expected Utility (EU) or Max Expected Utility (MEU)
            
3) Input specs:
    1) input file format: 
        a) File with ".txt" extension
        b) It contain "several queries" and "a Bayesian Network"
        c) First few lines are queries (one query per line)
            
            * Query Specs:
                a) Starting with "P": 
                        Asking for Specific Joint probabilities | Marginal probabilities | Conditional Probabilities
                        When there is no decision node or decision node has a set value.

                b) Starting with "EU":
                c) Starting with "MEU":
            
                A line with six '*' (like ******) is used as a seperator after all the queries,
                and it is followed by Bayesian network.

        d) Each table is seperated by ***
            
            * Table format:
                a) first line is  "<Node_name> [ | parent1 parent2 ...]
                b) Node name is in Upper_cammel letter and contains letters only. (EXCEPT utility node, it will have name "utility")
                c) only probabilieis of "+" for a node will be given.
                d) There won't be any order for the lines in table except first line.
                        (+, -) may appear after (-, +)
                e) Each node can have atmost 3 PARENTS
                f) There won't be any cycle
                g) Parent node's table will always occur before the child node's table

                h) For DECISION nodes second line of the table of that node will have keyword "decision" in it.
                i) A DECISIoN node will never have a parent node.
                j) There can be atmost 3 DECISION nodes.
                k) If there is DECISION node then there will be a "utility" node
                l) "utility" node table will be always at the end of file seperated from other tables by ******.
                m) Atmost one "utility" node with 3 parents.

4) Output Specs:
    a) for P query: a value between 0 and 1, rounded to 2 decimals
    b) for EU query: an Integer value
    c) for MEU query: A ("+" or "-") sign for each decision node followed by an integer value.
                        The order of decision (signs) must be same as order in query.
                        All seperated by single white space.
    d) store output in a "output.txt" file

NOTE:
    1) For EU and MEU queris do the calculations in DECIMAL but show the result ROUNDED to NEAREST integer value.
    2) No white space after value and no extra line break at end.
    3) Total number of nodes will be <= 10

'''
